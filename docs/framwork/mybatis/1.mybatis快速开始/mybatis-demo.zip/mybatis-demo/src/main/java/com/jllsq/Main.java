package com.jllsq;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

import java.io.IOException;
import java.io.InputStream;

public class Main {

    public static void main(String[] args) throws IOException {
        String resource = "mybatis-config.xml";
        InputStream inputStream = Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
        Blog blog = new Blog();
        blog.setTitle("first");
        blog.setContent("first");
        SqlSession sqlSession = sqlSessionFactory.openSession();
        sqlSession.insert("com.jllsq.BlogMapper.insertOne",blog);
        sqlSession.commit();
        sqlSession.close();
    }
}
